#!/bin/bash

# Tervitus
echo "Tere tulemast Bash skriptimise kursusele"

# Tühi rida
echo

# Tänane kuupäev
echo "Täna on:"
date

# Tühi rida
echo

# Teade
echo "See on hea päev Bash skriptimise alustamiseks"
